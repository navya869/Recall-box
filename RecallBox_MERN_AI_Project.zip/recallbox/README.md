# RecallBox — Your Digital Memory Assistant

RecallBox is a full-stack MERN app for saving notes, links, and documents and finding them later with natural-language **AI semantic search**.

## Features
- Clean responsive dashboard with search, filters, and saved-item cards.
- Save notes, web links, and upload TXT/MD/PDF/image files.
- Extract text from TXT/MD, PDF, and images (OCR).
- AI semantic search using a local sentence-embedding model (`Xenova/all-MiniLM-L6-v2`) through Transformers.js.
- If the AI model is still downloading or unavailable, the app uses a clearly indicated keyword-search fallback so the app remains usable.
- Search by meaning, e.g. “that recipe with chickpeas” or “the internship deadline”.
- Edit, delete, pin, and filter saved items.
- Works with MongoDB when configured, with a local JSON store fallback for quick local demos.
- No paid API keys are required. The first semantic search may download the model from Hugging Face and needs internet.

## Requirements
- Node.js 20 or newer
- npm
- Optional: MongoDB local installation or a free MongoDB Atlas database

## Run locally
1. Extract the ZIP.
2. Open a terminal in the `recallbox` folder.
3. Install dependencies:
   ```bash
   npm run install:all
   ```
4. Copy `server/.env.example` to `server/.env` and edit it if needed. Defaults work without MongoDB:
   ```env
   PORT=5000
   MONGO_URI=
   CLIENT_ORIGIN=http://localhost:5173
   ```
   If using MongoDB, set `MONGO_URI` to your local or Atlas connection string.
5. Start both apps:
   ```bash
   npm run dev
   ```
6. Open http://localhost:5173

### First AI search
The first semantic search initializes and downloads the sentence embedding model. This can take a few minutes depending on internet speed. Check the server terminal for model status. You can still save and search using keyword fallback while it loads.

## Supported item types
- Note: title and text
- Link: URL, title, and optional description
- File: PDF, TXT, Markdown, PNG, JPG/JPEG, WEBP

For PDF/image uploads, text extraction depends on the quality and language of the source. OCR may take time. Use non-sensitive sample documents for demos.

## Project structure
```
recallbox/
  client/                 React + Vite UI
  server/
    src/
      config/             storage connection
      middleware/         upload handling
      routes/             REST API
      services/            extraction, embeddings, search
      models/              MongoDB schema
      utils/               local JSON fallback store
    uploads/               uploaded files
```

## API
- `GET /api/health` — status and AI readiness
- `GET /api/items?q=&type=&pinned=` — search/list items
- `POST /api/items` — create note or link
- `POST /api/items/upload` — upload and extract supported file
- `PATCH /api/items/:id` — edit/pin item
- `DELETE /api/items/:id` — delete item
- `GET /api/items/:id/file` — retrieve an uploaded file

## Notes for a college submission
- This is a functional project starter, not a claim of production security or perfect OCR.
- Before public deployment, add authentication, rate limiting, malware scanning, private per-user data isolation, and secure cloud file storage. This local demo intentionally runs as a single-user workspace.
- Semantic search quality depends on the content saved and the embedding model. The fallback is lexical search, not AI.
