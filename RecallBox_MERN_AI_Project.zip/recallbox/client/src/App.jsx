import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  Search, Plus, Sparkles, FileText, Link2, Image as ImageIcon, Pin, PinOff,
  Trash2, Upload, X, ArrowUpRight, Clock3, Command, BrainCircuit, Filter,
  Check, LoaderCircle, SearchX, BookOpen, Menu, ChevronDown, FileUp, ExternalLink,
  MoreHorizontal, WandSparkles, AlertCircle, RefreshCw
} from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:5000/api";
const sampleItems = [
  { id: "sample-1", title: "Chickpea & spinach dinner idea", content: "A quick dinner recipe with chickpeas, spinach, garlic, lemon, cumin, and coconut milk. Serve with rice or flatbread. Save for busy weekday evenings.", type: "note", tags: ["recipe", "dinner"], pinned: true, createdAt: new Date(Date.now() - 86400000 * 2).toISOString(), sample: true },
  { id: "sample-2", title: "Portfolio inspiration — soft editorial layout", content: "Website inspiration with warm neutral colors, large typography, generous whitespace, rounded cards, and a simple portfolio case-study structure.", type: "link", url: "https://example.com", tags: ["design", "portfolio"], pinned: false, createdAt: new Date(Date.now() - 86400000 * 4).toISOString(), sample: true },
  { id: "sample-3", title: "Internship application checklist", content: "Update resume, prepare project links, check application deadline, write a short introduction, and keep a copy of the offer letter and certificates.", type: "note", tags: ["career", "checklist"], pinned: true, createdAt: new Date(Date.now() - 86400000 * 6).toISOString(), sample: true },
  { id: "sample-4", title: "Weekend trip ideas", content: "Places with green views, calm walking trails, local food, and a short travel time. Compare opening hours and weather before leaving.", type: "note", tags: ["travel", "weekend"], pinned: false, createdAt: new Date(Date.now() - 86400000 * 8).toISOString(), sample: true },
  { id: "sample-5", title: "JavaScript async/await notes", content: "Promises represent future results. Async functions return promises. Await pauses inside an async function until a promise settles. Use try/catch to handle failures.", type: "note", tags: ["coding", "javascript"], pinned: false, createdAt: new Date(Date.now() - 86400000 * 12).toISOString(), sample: true },
  { id: "sample-6", title: "A thoughtful birthday message", content: "A note about celebrating a close friend who always supports you, listens even when you are quiet, and makes ordinary days feel special.", type: "note", tags: ["personal", "writing"], pinned: false, createdAt: new Date(Date.now() - 86400000 * 14).toISOString(), sample: true }
];

function formatDate(date) {
  if (!date) return "Just now";
  const d = new Date(date);
  if (Number.isNaN(d.getTime())) return "Recently";
  const days = Math.floor((Date.now() - d.getTime()) / 86400000);
  if (days <= 0) return "Today";
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days} days ago`;
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}
function itemIcon(type) {
  if (type === "link") return <Link2 size={17} />;
  if (type === "file") return <FileText size={17} />;
  return <FileText size={17} />;
}
function previewText(item) {
  return (item.content || item.url || "No preview available yet.").replace(/\s+/g, " ").trim();
}
function escapeHtml(text) {
  return String(text).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[c]));
}

export default function App() {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [typeFilter, setTypeFilter] = useState("all");
  const [pinnedOnly, setPinnedOnly] = useState(false);
  const [searchMode, setSearchMode] = useState("recent");
  const [aiStatus, setAiStatus] = useState({ status: "checking", message: "Checking AI search…" });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [modal, setModal] = useState(null);
  const [toast, setToast] = useState("");
  const [mobileSidebar, setMobileSidebar] = useState(false);
  const [apiOnline, setApiOnline] = useState(false);
  const [showSearchHelp, setShowSearchHelp] = useState(false);
  const searchRef = useRef(null);
  const fileRef = useRef(null);
  const toastTimer = useRef(null);

  const notify = useCallback((message) => {
    setToast(message);
    if (toastTimer.current) clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToast(""), 2800);
  }, []);

  const loadItems = useCallback(async (search = query, type = typeFilter, pinned = pinnedOnly) => {
    setLoading(true);
    setError("");
    try {
      const params = new URLSearchParams();
      if (search.trim()) params.set("q", search.trim());
      if (type !== "all") params.set("type", type);
      if (pinned) params.set("pinned", "true");
      const response = await fetch(`${API}/items?${params.toString()}`);
      if (!response.ok) throw new Error("Could not load saved items.");
      const data = await response.json();
      setItems(data.items || []);
      setSearchMode(data.searchMode || (search ? "keyword" : "recent"));
      setAiStatus(data.ai || aiStatus);
      setApiOnline(true);
    } catch {
      setApiOnline(false);
      setItems([]);
      setError("Can't connect to RecallBox server. Start the app with `npm run dev` from the project folder.");
    } finally {
      setLoading(false);
    }
  }, [query, typeFilter, pinnedOnly, aiStatus]);

  useEffect(() => { loadItems("", "all", false); }, []); // initial load
  useEffect(() => {
    const id = setTimeout(() => {
      if (apiOnline) loadItems(query, typeFilter, pinnedOnly);
    }, query ? 380 : 0);
    return () => clearTimeout(id);
  }, [query, typeFilter, pinnedOnly, apiOnline]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    const handleKey = (event) => {
      const target = event.target;
      const typing = target && ["INPUT", "TEXTAREA"].includes(target.tagName);
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "k") {
        event.preventDefault(); searchRef.current?.focus();
      }
      if (event.key === "Escape") setModal(null);
      if (!typing && event.key === "/") { event.preventDefault(); searchRef.current?.focus(); }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const visibleItems = useMemo(() => items, [items]);
  const pinnedCount = useMemo(() => items.filter(item => item.pinned).length, [items]);

  async function createItem(payload) {
    const response = await fetch(`${API}/items`, {
      method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Couldn't save this item.");
    await loadItems(query, typeFilter, pinnedOnly);
    setModal(null);
    notify("Saved to RecallBox");
  }
  async function uploadFile(file, title = "") {
    const form = new FormData();
    form.append("file", file);
    if (title.trim()) form.append("title", title.trim());
    const response = await fetch(`${API}/items/upload`, { method: "POST", body: form });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Upload failed.");
    await loadItems(query, typeFilter, pinnedOnly);
    setModal(null);
    notify(`Saved file · ${data.extractedCharacters ?? 0} characters extracted`);
  }
  async function patchItem(item, changes) {
    if (item.sample) {
      notify("This is a demo item. Save your own item to edit it.");
      return;
    }
    const response = await fetch(`${API}/items/${item.id}`, {
      method: "PATCH", headers: { "Content-Type": "application/json" }, body: JSON.stringify(changes)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Update failed.");
    await loadItems(query, typeFilter, pinnedOnly);
    notify(changes.pinned ? "Pinned to your collection" : "Updated");
  }
  async function deleteItem(item) {
    if (item.sample) { notify("Demo items can't be deleted."); return; }
    if (!window.confirm(`Delete “${item.title}” from RecallBox?`)) return;
    const response = await fetch(`${API}/items/${item.id}`, { method: "DELETE" });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Delete failed.");
    await loadItems(query, typeFilter, pinnedOnly);
    notify("Item deleted");
  }
  async function handleSave(payload) {
    try {
      if (payload.file) await uploadFile(payload.file, payload.title);
      else await createItem(payload);
    } catch (e) { setError(e.message); notify(e.message); }
  }
  function openFile(item) {
    if (item.sample) { notify("Demo preview — upload your own file to open a real document."); return; }
    window.open(`${API}/items/${item.id}/file`, "_blank", "noopener,noreferrer");
  }
  const countsLabel = query ? `${visibleItems.length} ${visibleItems.length === 1 ? "result" : "results"}` : `${visibleItems.length} saved`;
  const searchModeLabel = searchMode === "ai" ? "AI semantic search" : searchMode === "keyword" ? "Keyword fallback" : "Ready when you are";

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileSidebar ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><BrainCircuit size={22} strokeWidth={2.3} /></div>
          <span>recall<span className="brand-accent">box</span></span>
          <button className="icon-button sidebar-close" onClick={() => setMobileSidebar(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <button className={`nav-item ${!pinnedOnly && typeFilter === "all" ? "active" : ""}`} onClick={() => { setPinnedOnly(false); setTypeFilter("all"); setMobileSidebar(false); }}>
          <BookOpen size={18}/><span>All memories</span><span className="nav-count">{items.length}</span>
        </button>
        <button className={`nav-item ${pinnedOnly ? "active" : ""}`} onClick={() => { setPinnedOnly(true); setMobileSidebar(false); }}>
          <Pin size={18}/><span>Pinned</span>
        </button>
        <div className="sidebar-label">YOUR LIBRARY</div>
        <button className={`nav-item ${typeFilter === "note" ? "active" : ""}`} onClick={() => { setTypeFilter(typeFilter === "note" ? "all" : "note"); setPinnedOnly(false); setMobileSidebar(false); }}>
          <span className="type-icon note-icon"><FileText size={15}/></span><span>Notes</span>
        </button>
        <button className={`nav-item ${typeFilter === "link" ? "active" : ""}`} onClick={() => { setTypeFilter(typeFilter === "link" ? "all" : "link"); setPinnedOnly(false); setMobileSidebar(false); }}>
          <span className="type-icon link-icon"><Link2 size={15}/></span><span>Links</span>
        </button>
        <button className={`nav-item ${typeFilter === "file" ? "active" : ""}`} onClick={() => { setTypeFilter(typeFilter === "file" ? "all" : "file"); setPinnedOnly(false); setMobileSidebar(false); }}>
          <span className="type-icon file-icon"><FileText size={15}/></span><span>Documents</span>
        </button>
        <div className="sidebar-spacer"/>
        <div className="ai-card">
          <div className="ai-card-icon"><Sparkles size={17}/></div>
          <div className="ai-card-title">A little help from AI</div>
          <p>Search the way you remember. We'll find the meaning behind your words.</p>
          <button className="text-button" onClick={() => { setShowSearchHelp(true); setMobileSidebar(false); }}>See search tips <ArrowUpRight size={14}/></button>
        </div>
        <div className="sidebar-footer">
          <div className={`status-dot ${apiOnline ? "online" : ""}`}/>
          <span>{apiOnline ? "Your space is ready" : "Connecting to your space"}</span>
          <button className="icon-button tiny" title="Refresh" onClick={() => loadItems()}><RefreshCw size={14}/></button>
        </div>
      </aside>

      {mobileSidebar && <button className="mobile-scrim" onClick={() => setMobileSidebar(false)} aria-label="Close navigation"/>}

      <main className="main-area">
        <header className="topbar">
          <button className="icon-button mobile-menu" onClick={() => setMobileSidebar(true)} aria-label="Open menu"><Menu size={20}/></button>
          <div className="breadcrumb">Your space <span>/</span> <strong>{pinnedOnly ? "Pinned memories" : typeFilter === "all" ? "All memories" : `${typeFilter[0].toUpperCase()}${typeFilter.slice(1)}s`}</strong></div>
          <div className="topbar-right">
            <div className="status-pill"><span className={`status-dot ${apiOnline ? "online" : ""}`}/>{apiOnline ? "All changes saved" : "Offline"}</div>
            <button className="avatar" title="Local demo workspace">N</button>
          </div>
        </header>

        <section className="content-wrap">
          <div className="welcome-row">
            <div>
              <div className="eyebrow"><Sparkles size={14}/> YOUR SECOND BRAIN</div>
              <h1>Everything you saved.<br/><span>Nothing lost.</span></h1>
              <p className="welcome-copy">That screenshot. That idea. That link you swore you'd remember.<br className="desktop-break"/> It's all here, just a thought away.</p>
            </div>
            <div className="hero-art" aria-hidden="true">
              <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
              <div className="float-card float-card-a"><ImageIcon size={18}/><span>summer-mood.png</span></div>
              <div className="float-card float-card-b"><FileText size={18}/><span>ideas & notes</span></div>
              <div className="brain-orb"><BrainCircuit size={46}/><span className="orb-sparkle"><Sparkles size={15}/></span></div>
              <div className="float-card float-card-c"><Link2 size={18}/><span>inspiration link</span></div>
            </div>
          </div>

          <div className="search-panel">
            <div className="search-leading"><Search size={21}/></div>
            <input ref={searchRef} value={query} onChange={e => setQuery(e.target.value)} placeholder="Search by a thought, not a filename..." aria-label="Search memories"/>
            {query && <button className="icon-button" onClick={() => setQuery("")} aria-label="Clear search"><X size={17}/></button>}
            <kbd><Command size={12}/> K</kbd>
            <button className="search-help-button" title="Search tips" onClick={() => setShowSearchHelp(v => !v)}><span>?</span></button>
          </div>
          <div className="search-subline">
            <span className={`ai-mini-dot ${searchMode === "ai" ? "active" : ""}`}><Sparkles size={12}/></span>
            <span>{query ? searchModeLabel : "Try asking in your own words"}</span>
            {query && searchMode === "keyword" && <span className="mode-note">AI model unavailable; using keyword matching</span>}
          </div>

          {showSearchHelp && (
            <div className="tips-panel">
              <div><Sparkles size={18}/><strong>Search like you remember</strong><button className="icon-button" onClick={() => setShowSearchHelp(false)}><X size={16}/></button></div>
              <p>Try a description instead of an exact title. AI search compares meaning, so the words don't have to match exactly.</p>
              <div className="example-chips">
                {["that recipe with chickpeas", "my internship deadline", "website design inspiration", "notes about JavaScript"].map(s => <button key={s} onClick={() => { setQuery(s); setShowSearchHelp(false); }}>{s}</button>)}
              </div>
            </div>
          )}

          {error && <div className="error-banner"><AlertCircle size={18}/><span>{error}</span><button className="text-button" onClick={() => loadItems()}>Retry</button></div>}

          <div className="section-heading">
            <div>
              <div className="section-title-row"><h2>{query ? "Found in your memories" : pinnedOnly ? "Your pinned memories" : "Recently remembered"}</h2><span className="result-count">{countsLabel}</span></div>
              <p>{query ? "The closest matches to what you're thinking of." : "A little collection of things worth keeping."}</p>
            </div>
            <div className="heading-actions">
              <button className="filter-button" onClick={() => { setTypeFilter(typeFilter === "all" ? "note" : typeFilter === "note" ? "link" : typeFilter === "link" ? "file" : "all"); setPinnedOnly(false); }}><Filter size={15}/>{typeFilter === "all" ? "All types" : typeFilter[0].toUpperCase() + typeFilter.slice(1)}<ChevronDown size={14}/></button>
              <button className="primary-button" onClick={() => setModal({ kind: "create" })}><Plus size={17}/> Save something</button>
            </div>
          </div>

          {loading ? (
            <div className="loading-state"><LoaderCircle className="spin" size={26}/><span>Gathering your memories…</span></div>
          ) : visibleItems.length === 0 ? (
            <div className="empty-state">
              <div className="empty-icon"><SearchX size={30}/></div>
              <h3>{query ? "Nothing surfaced just yet" : "Your next memory starts here"}</h3>
              <p>{query ? "Try a different phrase, or save the item you're looking for." : "Save a note, link, or document. Future you will be glad you did."}</p>
              <button className="primary-button" onClick={() => setModal({ kind: "create" })}><Plus size={17}/> Save your first memory</button>
            </div>
          ) : (
            <div className="memory-grid">
              {visibleItems.map((item, index) => (
                <article className={`memory-card ${item.pinned ? "is-pinned" : ""}`} key={item.id}>
                  <div className="card-topline">
                    <div className={`card-type ${item.type}`}>{itemIcon(item.type)}<span>{item.type === "file" ? "Document" : item.type === "link" ? "Link" : "Note"}</span></div>
                    <div className="card-actions">
                      {item.pinned && <span className="pin-indicator" title="Pinned"><Pin size={13} fill="currentColor"/></span>}
                      <button className="icon-button card-menu-button" title={item.pinned ? "Unpin" : "Pin"} onClick={() => patchItem(item, { pinned: !item.pinned })}>{item.pinned ? <PinOff size={15}/> : <Pin size={15}/>}</button>
                      {!item.sample && <button className="icon-button card-menu-button" title="Delete" onClick={() => deleteItem(item)}><Trash2 size={15}/></button>}
                    </div>
                  </div>
                  <button className="card-main" onClick={() => setModal({ kind: "detail", item })}>
                    <h3>{item.title}</h3>
                    <p>{previewText(item).slice(0, 160)}{previewText(item).length > 160 ? "…" : ""}</p>
                  </button>
                  {item.tags?.length > 0 && <div className="tag-row">{item.tags.slice(0, 3).map(tag => <span className="tag" key={tag}>#{tag}</span>)}</div>}
                  <div className="card-footer">
                    <span><Clock3 size={13}/>{formatDate(item.createdAt)}</span>
                    {typeof item.relevance === "number" && query && <span className="relevance"><Sparkles size={12}/>{item.relevance}% match</span>}
                    {item.type === "link" && item.url && <a href={item.url} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} className="open-link" aria-label="Open link"><ExternalLink size={14}/></a>}
                    {item.type === "file" && !item.sample && <button className="open-link" onClick={() => openFile(item)} title="Open original file"><ArrowUpRight size={15}/></button>}
                  </div>
                </article>
              ))}
            </div>
          )}

          <div className="bottom-note"><Sparkles size={14}/><span>{aiStatus.status === "ready" ? "Local AI is ready — search by meaning, not exact words." : aiStatus.status === "loading" ? "Warming up your local AI model. First load can take a little while." : "Your memories stay in your workspace. Semantic AI starts when its model is ready."}</span></div>
        </section>
        <footer className="page-footer"><span>RecallBox © 2026</span><span>Made for the things you don't want to forget <span className="heart">♥</span></span><button onClick={() => setShowSearchHelp(true)}>How search works</button></footer>
      </main>

      {modal && <Modal modal={modal} onClose={() => setModal(null)} onSave={handleSave} onPatch={patchItem} onDelete={deleteItem} notify={notify} />}
      {toast && <div className="toast"><span className="toast-check"><Check size={14}/></span>{toast}</div>}
    </div>
  );
}

function Modal({ modal, onClose, onSave, onPatch, onDelete, notify }) {
  const [kind, setKind] = useState("note");
  const [title, setTitle] = useState(modal.item?.title || "");
  const [content, setContent] = useState(modal.item?.content || "");
  const [url, setUrl] = useState(modal.item?.url || "");
  const [tags, setTags] = useState((modal.item?.tags || []).join(", "));
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState("");
  const fileInput = useRef(null);
  const isDetail = modal.kind === "detail";
  const item = modal.item;

  async function submit(event) {
    event.preventDefault();
    setLocalError("");
    if (kind !== "file" && !title.trim()) { setLocalError("Give this memory a title first."); return; }
    if (kind === "link") {
      try { const parsed = new URL(url); if (!["http:", "https:"].includes(parsed.protocol)) throw new Error(); }
      catch { setLocalError("Enter a complete link starting with https:// or http://"); return; }
    }
    setBusy(true);
    try {
      await onSave(file ? { file, title } : { title, content, url, type: kind, tags: tags.split(",").map(t => t.trim()).filter(Boolean) });
    } catch (error) { setLocalError(error.message); }
    finally { setBusy(false); }
  }

  async function saveEdit(event) {
    event.preventDefault();
    if (!title.trim()) { setLocalError("Title cannot be empty."); return; }
    setBusy(true);
    try {
      await onPatch(item, { title: title.trim(), content, tags: tags.split(",").map(t => t.trim()).filter(Boolean) });
      onClose();
    } catch (error) { setLocalError(error.message); }
    finally { setBusy(false); }
  }

  return (
    <div className="modal-backdrop" onMouseDown={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className={`modal ${isDetail ? "detail-modal" : ""}`} role="dialog" aria-modal="true" aria-labelledby="modal-title">
        <div className="modal-header">
          <div><div className="modal-kicker"><Sparkles size={13}/>{isDetail ? "MEMORY DETAILS" : "ADD TO YOUR SPACE"}</div><h2 id="modal-title">{isDetail ? item.title : "Save a memory"}</h2></div>
          <button className="icon-button modal-close" onClick={onClose} aria-label="Close"><X size={19}/></button>
        </div>
        {isDetail ? (
          <>
            <div className="detail-meta"><span className={`card-type ${item.type}`}>{itemIcon(item.type)}{item.type}</span><span><Clock3 size={14}/>{formatDate(item.createdAt)}</span>{item.pinned && <span><Pin size={13}/> Pinned</span>}</div>
            <div className="detail-content">{item.content || "No additional text saved."}</div>
            {item.url && <a className="detail-url" href={item.url} target="_blank" rel="noreferrer">{item.url} <ExternalLink size={15}/></a>}
            {item.tags?.length > 0 && <div className="tag-row detail-tags">{item.tags.map(tag => <span className="tag" key={tag}>#{tag}</span>)}</div>}
            {item.type === "file" && !item.sample && <button className="secondary-button full-button" onClick={() => window.open(`${API}/items/${item.id}/file`, "_blank", "noopener,noreferrer")}><FileUp size={16}/> Open original file</button>}
            <div className="modal-actions"><button className="secondary-button" onClick={onClose}>Close</button><button className="primary-button" onClick={() => { navigator.clipboard?.writeText([item.title, item.content, item.url].filter(Boolean).join("\n\n")); notify("Copied to clipboard"); }}><FileText size={15}/> Copy details</button></div>
          </>
        ) : (
          <form onSubmit={submit}>
            <div className="kind-tabs">
              {[["note", FileText, "Note"], ["link", Link2, "Link"], ["file", Upload, "File"]].map(([value, Icon, label]) => <button type="button" key={value} className={kind === value ? "selected" : ""} onClick={() => { setKind(value); setFile(null); setLocalError(""); }}><Icon size={16}/>{label}</button>)}
            </div>
            {kind === "file" ? (
              <div className={`drop-zone ${file ? "has-file" : ""}`} onClick={() => fileInput.current?.click()} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); const picked = e.dataTransfer.files?.[0]; if (picked) setFile(picked); }}>
                <input ref={fileInput} type="file" hidden accept=".pdf,.txt,.md,.csv,.json,.png,.jpg,.jpeg,.webp,.bmp" onChange={e => setFile(e.target.files?.[0] || null)}/>
                <div className="drop-icon">{file ? <Check size={24}/> : <Upload size={24}/>}</div>
                <strong>{file ? file.name : "Drop a file here, or browse"}</strong>
                <span>{file ? `${(file.size / 1024 / 1024).toFixed(2)} MB · Ready to extract text` : "PDF, TXT, MD, CSV, JSON, PNG, JPG or WEBP · Up to 12 MB"}</span>
                {file && <button type="button" className="text-button" onClick={e => { e.stopPropagation(); setFile(null); }}>Choose another</button>}
              </div>
            ) : (
              <>
                <label className="field-label">Title <span>*</span><input autoFocus value={title} onChange={e => setTitle(e.target.value)} placeholder={kind === "link" ? "What is this link about?" : "Give this memory a name"} maxLength={180}/></label>
                {kind === "link" && <label className="field-label">Website URL <span>*</span><input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://example.com" type="url"/></label>}
                <label className="field-label">{kind === "link" ? "Why save it? (optional)" : "Your note"}<textarea value={content} onChange={e => setContent(e.target.value)} placeholder={kind === "link" ? "What do you want to remember about this link?" : "Write or paste anything you want to find later…"} rows={5}/></label>
              </>
            )}
            {kind === "file" && <label className="field-label">Title (optional)<input value={title} onChange={e => setTitle(e.target.value)} placeholder={file ? file.name.replace(/\.[^.]+$/, "") : "Use the filename by default"}/></label>}
            <label className="field-label">Tags <span className="optional">(comma separated)</span><input value={tags} onChange={e => setTags(e.target.value)} placeholder="e.g. work, ideas, recipes"/></label>
            {localError && <div className="form-error"><AlertCircle size={15}/>{localError}</div>}
            <div className="privacy-hint"><BrainCircuit size={16}/><span>RecallBox will index the text so you can find it later by meaning.</span></div>
            <div className="modal-actions"><button type="button" className="secondary-button" onClick={onClose}>Cancel</button><button type="submit" className="primary-button" disabled={busy || (kind === "file" && !file)}>{busy ? <><LoaderCircle size={16} className="spin"/> Saving…</> : <><Sparkles size={16}/> Save memory</>}</button></div>
          </form>
        )}
      </div>
    </div>
  );
}
