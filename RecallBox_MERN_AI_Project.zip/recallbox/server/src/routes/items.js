import { Router } from "express";
import fs from "node:fs/promises";
import path from "node:path";
import mongoose from "mongoose";
import Item from "../models/Item.js";
import { readItems, writeItems, newId } from "../utils/localStore.js";
import { embedText, cosineSimilarity, getAIStatus } from "../services/embeddings.js";
import { extractUploadedText } from "../services/extractText.js";
import { upload } from "../middleware/upload.js";

const router = Router();
let useMongo = false;
export function setStorageMode(enabled) { useMongo = enabled; }

function asPublic(item) {
  const value = item?.toObject ? item.toObject() : item;
  const { embedding, storedName, ...rest } = value;
  return { ...rest, id: String(value._id || value.id), hasFile: Boolean(storedName) };
}
function itemText(item) {
  return [item.title, item.content, item.url, ...(item.tags || [])].filter(Boolean).join("\n");
}
async function getAll() {
  return useMongo ? Item.find({}).sort({ pinned: -1, updatedAt: -1 }).lean() : readItems();
}
async function saveItem(data) {
  if (useMongo) return await Item.create(data);
  const items = await readItems();
  const item = { ...data, _id: newId(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
  items.unshift(item); await writeItems(items); return item;
}
async function updateItem(id, changes) {
  if (useMongo) return await Item.findByIdAndUpdate(id, { ...changes, updatedAt: new Date() }, { new: true });
  const items = await readItems();
  const index = items.findIndex((item) => item._id === id || item.id === id);
  if (index < 0) return null;
  items[index] = { ...items[index], ...changes, updatedAt: new Date().toISOString() };
  await writeItems(items); return items[index];
}
async function removeItem(id) {
  if (useMongo) return await Item.findByIdAndDelete(id);
  const items = await readItems();
  const found = items.find((item) => item._id === id || item.id === id);
  await writeItems(items.filter((item) => item._id !== id && item.id !== id));
  return found || null;
}
async function buildEmbedding(data) {
  try { return await embedText(itemText(data)); }
  catch (error) { console.warn("Embedding unavailable; saved item without vector:", error.message); return undefined; }
}
function normalizeTags(tags) {
  if (Array.isArray(tags)) return tags.map(String).map(s => s.trim()).filter(Boolean).slice(0, 12);
  return String(tags || "").split(",").map(s => s.trim()).filter(Boolean).slice(0, 12);
}
function scoreKeyword(query, item) {
  const q = query.toLowerCase().trim();
  if (!q) return 0;
  const text = itemText(item).toLowerCase();
  const terms = [...new Set(q.split(/[^a-z0-9]+/i).filter(w => w.length > 1))];
  if (!terms.length) return text.includes(q) ? 1 : 0;
  let score = 0;
  for (const term of terms) {
    if (String(item.title || "").toLowerCase().includes(term)) score += 3;
    else if (text.includes(term)) score += 1;
  }
  return score / (terms.length * 3);
}

router.get("/", async (req, res, next) => {
  try {
    const { q = "", type = "all", pinned = "all" } = req.query;
    let items = await getAll();
    if (type !== "all") items = items.filter(item => item.type === type);
    if (pinned === "true") items = items.filter(item => item.pinned);
    if (pinned === "false") items = items.filter(item => !item.pinned);
    let mode = "recent";
    if (String(q).trim()) {
      const query = String(q).trim().slice(0, 1000);
      let queryEmbedding = null;
      try { queryEmbedding = await embedText(query); mode = "ai"; }
      catch { mode = "keyword"; }
      const scored = items.map(item => {
        const vectorScore = queryEmbedding && item.embedding ? cosineSimilarity(queryEmbedding, item.embedding) : 0;
        const keywordScore = scoreKeyword(query, item);
        return { item, score: queryEmbedding ? vectorScore * 0.82 + keywordScore * 0.18 : keywordScore };
      }).filter(row => row.score > (mode === "ai" ? 0.16 : 0))
        .sort((a, b) => b.score - a.score || new Date(b.item.updatedAt) - new Date(a.item.updatedAt));
      items = scored.map(row => ({ ...row.item, relevance: Math.round(row.score * 100) }));
    } else {
      items.sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || new Date(b.updatedAt) - new Date(a.updatedAt));
    }
    res.json({ items: items.map(asPublic), searchMode: mode, ai: getAIStatus() });
  } catch (error) { next(error); }
});

router.post("/", async (req, res, next) => {
  try {
    const { title, content = "", type = "note", url = "", tags = [] } = req.body || {};
    if (!String(title || "").trim()) return res.status(400).json({ error: "Please add a title." });
    if (!["note", "link"].includes(type)) return res.status(400).json({ error: "Type must be note or link." });
    if (type === "link") {
      try { const parsed = new URL(url); if (!["http:", "https:"].includes(parsed.protocol)) throw new Error(); }
      catch { return res.status(400).json({ error: "Please enter a valid http or https link." }); }
    }
    const data = { title: String(title).trim().slice(0, 180), content: String(content).slice(0, 180000), type, url: type === "link" ? url : "", tags: normalizeTags(tags), pinned: false };
    data.embedding = await buildEmbedding(data);
    const item = await saveItem(data);
    res.status(201).json({ item: asPublic(item), ai: getAIStatus() });
  } catch (error) { next(error); }
});

router.post("/upload", upload.single("file"), async (req, res, next) => {
  if (!req.file) return res.status(400).json({ error: "Choose a file to upload." });
  try {
    let content = "";
    try { content = await extractUploadedText(req.file); }
    catch (error) {
      await fs.unlink(req.file.path).catch(() => {});
      return res.status(400).json({ error: error.message || "Could not read this file." });
    }
    const title = String(req.body.title || path.parse(req.file.originalname).name || "Uploaded file").trim().slice(0, 180);
    const data = { title, content, type: "file", url: "", originalName: req.file.originalname, storedName: path.basename(req.file.path), mimeType: req.file.mimetype, tags: normalizeTags(req.body.tags), pinned: false };
    data.embedding = await buildEmbedding(data);
    const item = await saveItem(data);
    res.status(201).json({ item: asPublic(item), extractedCharacters: content.length, ai: getAIStatus() });
  } catch (error) {
    await fs.unlink(req.file.path).catch(() => {});
    next(error);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    const changes = {};
    if (typeof req.body.title === "string") {
      if (!req.body.title.trim()) return res.status(400).json({ error: "Title cannot be empty." });
      changes.title = req.body.title.trim().slice(0, 180);
    }
    if (typeof req.body.content === "string") changes.content = req.body.content.slice(0, 180000);
    if (typeof req.body.pinned === "boolean") changes.pinned = req.body.pinned;
    if (req.body.tags !== undefined) changes.tags = normalizeTags(req.body.tags);
    if ("title" in changes || "content" in changes) {
      const all = await getAll();
      const current = all.find(item => String(item._id || item.id) === req.params.id);
      if (current) changes.embedding = await buildEmbedding({ ...current, ...changes });
    }
    const item = await updateItem(req.params.id, changes);
    if (!item) return res.status(404).json({ error: "Saved item not found." });
    res.json({ item: asPublic(item) });
  } catch (error) { next(error); }
});

router.delete("/:id", async (req, res, next) => {
  try {
    const item = await removeItem(req.params.id);
    if (!item) return res.status(404).json({ error: "Saved item not found." });
    const storedName = item.storedName;
    if (storedName) await fs.unlink(path.resolve("uploads", path.basename(storedName))).catch(() => {});
    res.json({ success: true });
  } catch (error) { next(error); }
});

router.get("/:id/file", async (req, res, next) => {
  try {
    const all = await getAll();
    const item = all.find(value => String(value._id || value.id) === req.params.id);
    if (!item || !item.storedName) return res.status(404).json({ error: "File not found." });
    const filePath = path.resolve("uploads", path.basename(item.storedName));
    res.download(filePath, item.originalName || item.title, error => { if (error && !res.headersSent) next(error); });
  } catch (error) { next(error); }
});

export default router;
