import { pipeline, env } from "@huggingface/transformers";

env.allowLocalModels = true;
env.allowRemoteModels = true;

let extractorPromise;
let aiState = { status: "not-loaded", message: "AI model loads on the first search." };

export function getAIStatus() { return aiState; }

async function getExtractor() {
  if (!extractorPromise) {
    aiState = { status: "loading", message: "Downloading/loading local embedding model. First run can take a few minutes." };
    extractorPromise = pipeline("feature-extraction", "Xenova/all-MiniLM-L6-v2", {
      quantized: true
    }).then((model) => {
      aiState = { status: "ready", message: "Local AI semantic search is ready." };
      return model;
    }).catch((error) => {
      aiState = { status: "unavailable", message: `AI model unavailable: ${error.message}` };
      extractorPromise = null;
      throw error;
    });
  }
  return extractorPromise;
}

export async function embedText(text) {
  const clean = String(text || "").trim().slice(0, 6000);
  if (!clean) return null;
  const extractor = await getExtractor();
  const output = await extractor(clean, { pooling: "mean", normalize: true });
  return Array.from(output.data);
}

export function cosineSimilarity(a, b) {
  if (!a?.length || !b?.length || a.length !== b.length) return 0;
  let dot = 0, normA = 0, normB = 0;
  for (let i = 0; i < a.length; i++) {
    dot += a[i] * b[i]; normA += a[i] * a[i]; normB += b[i] * b[i];
  }
  return normA && normB ? dot / (Math.sqrt(normA) * Math.sqrt(normB)) : 0;
}
