import fs from "node:fs/promises";
import path from "node:path";
import pdf from "pdf-parse";
import Tesseract from "tesseract.js";

const TEXT_LIMIT = 180000;
export async function extractUploadedText(file) {
  const ext = path.extname(file.originalname || "").toLowerCase();
  if ([".txt", ".md", ".csv", ".json"].includes(ext)) {
    return (await fs.readFile(file.path, "utf8")).slice(0, TEXT_LIMIT);
  }
  if (ext === ".pdf") {
    const buffer = await fs.readFile(file.path);
    const result = await pdf(buffer);
    return String(result.text || "").slice(0, TEXT_LIMIT);
  }
  if ([".png", ".jpg", ".jpeg", ".webp", ".bmp"].includes(ext)) {
    const result = await Tesseract.recognize(file.path, "eng");
    return String(result.data?.text || "").slice(0, TEXT_LIMIT);
  }
  throw new Error("Unsupported file type. Upload PDF, TXT, MD, CSV, JSON, PNG, JPG, or WEBP.");
}
