import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = path.resolve(here, "../../data");
const dataFile = path.join(dataDir, "items.json");

async function ensureFile() {
  await fs.mkdir(dataDir, { recursive: true });
  try { await fs.access(dataFile); }
  catch { await fs.writeFile(dataFile, "[]", "utf8"); }
}
export async function readItems() {
  await ensureFile();
  try { return JSON.parse(await fs.readFile(dataFile, "utf8")); }
  catch { return []; }
}
export async function writeItems(items) {
  await ensureFile();
  const tmp = `${dataFile}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(items, null, 2), "utf8");
  await fs.rename(tmp, dataFile);
}
export function newId() {
  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 10)}`;
}
