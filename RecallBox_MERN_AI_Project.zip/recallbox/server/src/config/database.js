import mongoose from "mongoose";

export async function connectMongo(uri) {
  if (!uri) {
    console.log("MONGO_URI not set: using local JSON storage.");
    return false;
  }
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log("Connected to MongoDB.");
    return true;
  } catch (error) {
    console.warn("MongoDB connection failed; using local JSON storage:", error.message);
    return false;
  }
}
