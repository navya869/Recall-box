import mongoose from "mongoose";

const itemSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true, maxlength: 180 },
  content: { type: String, default: "", maxlength: 200000 },
  type: { type: String, enum: ["note", "link", "file"], default: "note" },
  url: { type: String, default: "" },
  originalName: { type: String, default: "" },
  storedName: { type: String, default: "" },
  mimeType: { type: String, default: "" },
  tags: { type: [String], default: [] },
  pinned: { type: Boolean, default: false },
  embedding: { type: [Number], default: undefined },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
}, { versionKey: false });

itemSchema.index({ title: "text", content: "text", tags: "text" });
export default mongoose.models.Item || mongoose.model("Item", itemSchema);
