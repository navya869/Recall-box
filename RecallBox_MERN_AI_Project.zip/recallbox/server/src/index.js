import "dotenv/config";
import express from "express";
import cors from "cors";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { connectMongo } from "./config/database.js";
import itemRoutes, { setStorageMode } from "./routes/items.js";
import { getAIStatus } from "./services/embeddings.js";

const app = express();
const port = Number(process.env.PORT || 5000);
const here = path.dirname(fileURLToPath(import.meta.url));
const serverRoot = path.resolve(here, "..");
process.chdir(serverRoot);

app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173" }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true, limit: "1mb" }));

app.get("/api/health", (_req, res) => res.json({
  ok: true,
  app: "RecallBox API",
  storage: process.env.MONGO_URI ? "MongoDB configured (JSON fallback if connection failed)" : "local JSON",
  ai: getAIStatus()
}));
app.use("/api/items", itemRoutes);
app.use((err, _req, res, _next) => {
  console.error(err);
  const status = err.status || (err.name === "MulterError" ? 400 : 500);
  res.status(status).json({ error: status === 500 ? "Something went wrong. Check the server terminal for details." : err.message });
});

const mongoConnected = await connectMongo(process.env.MONGO_URI);
setStorageMode(mongoConnected);
app.listen(port, () => console.log(`RecallBox API running at http://localhost:${port}`));
